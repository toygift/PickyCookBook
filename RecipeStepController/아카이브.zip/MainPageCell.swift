//
//  MainPageCell.swift
//  RecipeStepController
//
//  Created by js on 2017. 8. 23..
//  Copyright © 2017년 sevenTeam. All rights reserved.
//

import UIKit

class MainPageCell: UITableViewCell {

    // MARK: OUTLET
    
    @IBOutlet var imgRecipe:UIImageView!
    @IBOutlet var titleName: UILabel!
    @IBOutlet var descName: UILabel!
    @IBOutlet var ingredName: UILabel!
    @IBOutlet var tagName: UILabel!
    @IBOutlet var rateSum: UILabel!
    @IBOutlet var likeCount: UILabel!
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
