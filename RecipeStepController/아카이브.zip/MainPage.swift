//
//  MainPage.swift
//  RecipeStepController
//
//  Created by js on 2017. 8. 23..
//  Copyright © 2017년 sevenTeam. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import Toaster

class MainPage: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var data: JSON = JSON.init(rawValue: [])!
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchUserData()
        self.tableView.reloadData()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
extension MainPage {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "mainpagecell") as? MainPageCell
        
        let recipeTitle = self.data[indexPath.row]["title"].stringValue
        let recipeDesc = self.data[indexPath.row]["description"].stringValue
        let recipeIngre = self.data[indexPath.row]["infredient"].stringValue
        let recipeTag = self.data[indexPath.row]["tag"].stringValue
        let recipeRate = self.data[indexPath.row]["rate_sum"].doubleValue
        let recipeLike = self.data[indexPath.row]["like_count"].intValue
        if let path = self.data[indexPath.row]["img_recipe"].string {
            if let imageData = try? Data(contentsOf: URL(string: path)!) {
                cell?.imgRecipe.image = UIImage(data: imageData)
            }
        }
        cell?.titleName.text = recipeTitle
        cell?.descName.text = recipeDesc
        cell?.ingredName.text = recipeIngre
        cell?.tagName.text = recipeTag
        cell?.rateSum.text = "\(recipeRate)"
        cell?.likeCount.text = "\(recipeLike)"
        
        
        return cell!
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let recipePK = self.data[indexPath.row]["pk"].intValue
        let detailViewController = storyboard?.instantiateViewController(withIdentifier: "\(recipePK)")
        tableView.deselectRow(at: indexPath, animated: true)
        self.navigationController?.pushViewController(detailViewController!, animated: true)
    }
}

extension MainPage {
    func fetchUserData(){
        let url = "http://pickycookbook.co.kr/api/recipe/"
        Alamofire.request(url, method: .get).responseJSON { (response) in
            switch response.result {
            case .success(let value):
                let result = JSON(value)
                print(result)
                self.data = JSON(value)
                self.tableView.reloadData()
                print(self.data)
                
           case .failure(let error):
                print(error)
                
            }
        }
    }
}
